"""
AutoTrader — Monitors scanner output and automatically executes trades
when conditions are met. Runs as a background asyncio task.

Auto-trade lifecycle:
1. Check if auto_trade_enabled == true in config
2. Find opportunities above auto_min_profit_pct threshold
3. Check cooldown, max concurrent trades, emergency stop
4. Delegate to TradeExecutor
5. Log result, update cooldown
"""

import asyncio
import logging
import time
from datetime import datetime
from typing import Optional, TYPE_CHECKING

from core.database import (
    AsyncSessionLocal, SystemConfig, Trade, TradeCooldown,
    TradeStatus, get_config
)
from core.config import settings
from sqlalchemy import select, func

if TYPE_CHECKING:
    from core.scanner import ArbitrageScanner

logger = logging.getLogger("nexarb.auto_trader")


class AutoTrader:
    """Background worker that auto-executes profitable opportunities"""

    def __init__(self, scanner: "ArbitrageScanner"):
        self.scanner = scanner
        self.running = False
        self.enabled = False
        self._stop = asyncio.Event()
        self._active_trades: set = set()

    def stop(self):
        self._stop.set()
        self.running = False

    async def run_forever(self):
        self.running = True
        logger.info("AutoTrader started (disabled by default)")

        while not self._stop.is_set():
            try:
                await self._tick()
            except Exception as e:
                logger.error(f"AutoTrader tick error: {e}", exc_info=True)

            try:
                await asyncio.wait_for(
                    self._stop.wait(),
                    timeout=settings.AUTO_TRADE_CHECK_INTERVAL,
                )
            except asyncio.TimeoutError:
                pass

        self.running = False
        logger.info("AutoTrader stopped")

    async def _tick(self):
        config = await get_config()

        # Check kill switches
        if config.get("emergency_stop", "false") == "true":
            self.enabled = False
            return

        self.enabled = config.get("auto_trade_enabled", "false") == "true"
        if not self.enabled:
            return

        # Check concurrent trade limit
        max_concurrent = int(config.get("max_concurrent_trades", 2))
        active_count = await self._count_active_trades()
        if active_count >= max_concurrent:
            logger.debug(f"AutoTrader: {active_count} active trades, limit {max_concurrent}")
            return

        auto_min_profit = float(config.get("auto_min_profit_pct", 1.5))
        capital         = float(config.get("max_capital_usdt", 120.0))
        arb_mode        = config.get("auto_trade_mode", "transfer")
        cooldown_secs   = int(config.get("cooldown_seconds", 300))

        # Find best eligible opportunity
        best = None
        for opp in self.scanner.opportunities:
            if opp["status"] != "PROFIT":
                continue
            if opp["net_profit_pct"] < auto_min_profit:
                continue
            if not opp["network_matched"] or not opp["withdrawal_ok"] or not opp["deposit_ok"]:
                continue
            if opp["symbol"] in self._active_trades:
                continue

            # Check cooldown
            if await self._is_on_cooldown(opp["symbol"], cooldown_secs):
                continue

            # Fresh opportunity only (scanned within last 15s)
            scanned_at = opp.get("scanned_at", "")
            if scanned_at:
                try:
                    age = (datetime.utcnow() - datetime.fromisoformat(scanned_at)).total_seconds()
                    if age > 15:
                        continue
                except Exception:
                    pass

            best = opp
            break

        if not best:
            return

        # Trigger trade
        logger.info(
            f"AutoTrader: triggering {best['symbol']} "
            f"{best['buy_exchange']}→{best['sell_exchange']} "
            f"net={best['net_profit_pct']:.2f}%"
        )

        self._active_trades.add(best["symbol"])
        try:
            from services.executor import TradeExecutor
            executor = TradeExecutor(self.scanner.clients)
            trade_id = await executor.execute(best, capital, config, exec_mode="auto")
            asyncio.create_task(self._track_trade_completion(trade_id, best["symbol"]))
        except Exception as e:
            logger.error(f"AutoTrader execute error: {e}", exc_info=True)
            self._active_trades.discard(best["symbol"])

    async def _track_trade_completion(self, trade_id: int, symbol: str):
        """Wait for trade to complete, then release slot"""
        try:
            while True:
                await asyncio.sleep(10)
                async with AsyncSessionLocal() as session:
                    result = await session.execute(
                        select(Trade.status).where(Trade.id == trade_id)
                    )
                    status = result.scalar_one_or_none()
                    if status in (
                        TradeStatus.COMPLETED,
                        TradeStatus.FAILED,
                        TradeStatus.CANCELLED,
                    ):
                        # Record cooldown
                        await self._set_cooldown(symbol)
                        self._active_trades.discard(symbol)
                        logger.info(f"AutoTrader: trade #{trade_id} finished with status={status}")
                        return
        except Exception as e:
            logger.error(f"Track trade error: {e}")
            self._active_trades.discard(symbol)

    async def _count_active_trades(self) -> int:
        async with AsyncSessionLocal() as session:
            result = await session.execute(
                select(func.count(Trade.id)).where(
                    Trade.status.in_([
                        TradeStatus.BUYING,
                        TradeStatus.WITHDRAWING,
                        TradeStatus.WAITING_DEPOSIT,
                        TradeStatus.RECHECKING,
                        TradeStatus.SELLING,
                    ])
                )
            )
            return result.scalar() or 0

    async def _is_on_cooldown(self, symbol: str, cooldown_secs: int) -> bool:
        async with AsyncSessionLocal() as session:
            result = await session.execute(
                select(TradeCooldown).where(TradeCooldown.symbol == symbol)
            )
            cd = result.scalar_one_or_none()
            if not cd:
                return False
            elapsed = (datetime.utcnow() - cd.last_trade_at).total_seconds()
            return elapsed < cooldown_secs

    async def _set_cooldown(self, symbol: str):
        async with AsyncSessionLocal() as session:
            result = await session.execute(
                select(TradeCooldown).where(TradeCooldown.symbol == symbol)
            )
            cd = result.scalar_one_or_none()
            if cd:
                cd.last_trade_at = datetime.utcnow()
            else:
                session.add(TradeCooldown(symbol=symbol))
            await session.commit()
