"""
Configuration Settings — loaded from .env
"""

from pydantic_settings import BaseSettings
from typing import List
import os


class Settings(BaseSettings):
    # ── App ──────────────────────────────────────────────────
    APP_NAME: str = "NEXARB"
    DEBUG: bool = False
    HOST: str = "0.0.0.0"
    PORT: int = 8000

    # ── Database ─────────────────────────────────────────────
    DATABASE_URL: str = "postgresql+asyncpg://nexarb:nexarb_pass@localhost/nexarb_db"

    # ── Security ─────────────────────────────────────────────
    SECRET_KEY: str = "CHANGE_THIS_IN_PRODUCTION"
    JWT_SECRET: str = "CHANGE_THIS_JWT_SECRET"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRE_HOURS: int = 24

    # ── Admin Credentials ────────────────────────────────────
    ADMIN_USERNAME: str = "admin"
    ADMIN_PASSWORD_HASH: str = ""   # bcrypt hash — set via env

    # ── Encryption (for API keys at rest) ────────────────────
    ENCRYPTION_KEY: str = "CHANGE_THIS_FERNET_KEY"

    # ── CORS ─────────────────────────────────────────────────
    ALLOWED_ORIGINS: List[str] = ["http://localhost:3000", "http://localhost:8000"]

    # ── Scanner Defaults ─────────────────────────────────────
    SCAN_INTERVAL_SECONDS: int = 5
    ORDERBOOK_DEPTH: int = 5
    BATCH_SIZE: int = 8
    MAX_PAIRS_PER_SCAN: int = 300
    CACHE_TTL_SECONDS: int = 300          # currency info cache
    REQUEST_TIMEOUT_MS: int = 12000

    # ── Trading Defaults (overridden by DB config) ────────────
    DEFAULT_MIN_PROFIT_PCT: float = 1.2
    DEFAULT_MAX_CAPITAL_USDT: float = 120.0
    DEFAULT_SLIPPAGE_PCT: float = 0.10
    DEFAULT_MAX_TRANSFER_MIN: int = 60
    DEFAULT_COOLDOWN_SECONDS: int = 300

    # ── Auto-Trade ───────────────────────────────────────────
    AUTO_TRADE_ENABLED_DEFAULT: bool = False   # OFF by default, user turns on
    AUTO_TRADE_CHECK_INTERVAL: int = 5         # seconds between checks
    MAX_CONCURRENT_TRADES: int = 2

    # ── Telegram Notifications (optional) ────────────────────
    TELEGRAM_BOT_TOKEN: str = ""
    TELEGRAM_CHAT_ID: str = ""

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()

# ── 30 Exchanges ─────────────────────────────────────────────────────────────
EXCHANGES = [
    # Tier 1 — Major global
    "binance", "bybit", "okx", "kucoin", "gate",
    "mexc", "huobi", "bitget", "phemex", "bingx",
    # Tier 2 — Western
    "coinbase", "kraken", "bitfinex", "gemini", "bitstamp",
    # Tier 3 — Mid-size (arbitrage gaps common here)
    "lbank", "bitmart", "ascendex", "xt", "coinex",
    "probit", "whitebit", "latoken", "poloniex", "exmo",
    # Tier 4 — Regional / Niche
    "yobit", "crex24", "p2pb2b", "btcturk", "tidex",
]
