"""
SQLAlchemy Async Models — Full Schema
"""

from datetime import datetime
from typing import Optional
from sqlalchemy import (
    String, Float, Boolean, DateTime, Text,
    JSON, Integer, ForeignKey, Enum as SAEnum
)
from sqlalchemy.ext.asyncio import (
    create_async_engine, AsyncSession, async_sessionmaker
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
import enum

from core.config import settings

# ── Engine ───────────────────────────────────────────────────────────────────
engine = create_async_engine(
    settings.DATABASE_URL,
    echo=settings.DEBUG,
    pool_size=10,
    max_overflow=20,
    pool_pre_ping=True,
)
AsyncSessionLocal = async_sessionmaker(
    engine, class_=AsyncSession, expire_on_commit=False
)


class Base(DeclarativeBase):
    pass


# ── Enums ─────────────────────────────────────────────────────────────────────
class TradeStatus(str, enum.Enum):
    PENDING          = "pending"
    BUYING           = "buying"
    WITHDRAWING      = "withdrawing"
    WAITING_DEPOSIT  = "waiting_deposit"
    RECHECKING       = "rechecking"
    SELLING          = "selling"
    LIMIT_PLACED     = "limit_placed"
    COMPLETED        = "completed"
    FAILED           = "failed"
    CANCELLED        = "cancelled"

class ArbMode(str, enum.Enum):
    TRANSFER      = "transfer"       # buy → withdraw → sell
    SIMULTANEOUS  = "simultaneous"   # buy + sell at same time

class ExecMode(str, enum.Enum):
    MANUAL = "manual"
    AUTO   = "auto"


# ── Tables ───────────────────────────────────────────────────────────────────

class ExchangeKey(Base):
    """Encrypted API keys per exchange"""
    __tablename__ = "exchange_keys"

    id: Mapped[int]                     = mapped_column(Integer, primary_key=True)
    exchange_id: Mapped[str]            = mapped_column(String(50), unique=True, index=True)
    display_name: Mapped[str]           = mapped_column(String(100))
    api_key_enc: Mapped[str]            = mapped_column(Text)
    api_secret_enc: Mapped[str]         = mapped_column(Text)
    api_pass_enc: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    is_enabled: Mapped[bool]            = mapped_column(Boolean, default=True)
    withdrawal_enabled: Mapped[bool]    = mapped_column(Boolean, default=False)
    ip_whitelist: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    note: Mapped[Optional[str]]         = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime]        = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime]        = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class SystemConfig(Base):
    """Key-value config store"""
    __tablename__ = "system_config"

    id: Mapped[int]          = mapped_column(Integer, primary_key=True)
    key: Mapped[str]         = mapped_column(String(100), unique=True, index=True)
    value: Mapped[str]       = mapped_column(Text)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Opportunity(Base):
    """Snapshot of a detected arbitrage opportunity"""
    __tablename__ = "opportunities"

    id: Mapped[int]                              = mapped_column(Integer, primary_key=True)
    symbol: Mapped[str]                          = mapped_column(String(30), index=True)
    buy_exchange: Mapped[str]                    = mapped_column(String(50))
    sell_exchange: Mapped[str]                   = mapped_column(String(50))
    buy_price: Mapped[float]                     = mapped_column(Float)
    sell_price: Mapped[float]                    = mapped_column(Float)
    network: Mapped[Optional[str]]               = mapped_column(String(50), nullable=True)
    available_networks: Mapped[Optional[dict]]   = mapped_column(JSON, nullable=True)
    buy_fee_pct: Mapped[float]                   = mapped_column(Float, default=0.1)
    sell_fee_pct: Mapped[float]                  = mapped_column(Float, default=0.1)
    withdrawal_fee_usd: Mapped[float]            = mapped_column(Float, default=0)
    withdrawal_fee_pct: Mapped[float]            = mapped_column(Float, default=0)
    slippage_pct: Mapped[float]                  = mapped_column(Float, default=0.1)
    gross_profit_pct: Mapped[float]              = mapped_column(Float)
    net_profit_pct: Mapped[float]                = mapped_column(Float)
    network_matched: Mapped[bool]                = mapped_column(Boolean, default=False)
    withdrawal_ok: Mapped[bool]                  = mapped_column(Boolean, default=False)
    deposit_ok: Mapped[bool]                     = mapped_column(Boolean, default=False)
    status: Mapped[str]                          = mapped_column(String(20), default="active")
    warn_reason: Mapped[Optional[str]]           = mapped_column(String(100), nullable=True)
    scanned_at: Mapped[datetime]                 = mapped_column(DateTime, default=datetime.utcnow, index=True)


class Trade(Base):
    """Full trade lifecycle record"""
    __tablename__ = "trades"

    id: Mapped[int]                              = mapped_column(Integer, primary_key=True)
    opportunity_id: Mapped[Optional[int]]        = mapped_column(Integer, ForeignKey("opportunities.id"), nullable=True)
    exec_mode: Mapped[str]                       = mapped_column(String(10), default=ExecMode.MANUAL)
    arb_mode: Mapped[str]                        = mapped_column(String(15), default=ArbMode.TRANSFER)
    symbol: Mapped[str]                          = mapped_column(String(30), index=True)
    buy_exchange: Mapped[str]                    = mapped_column(String(50))
    sell_exchange: Mapped[str]                   = mapped_column(String(50))

    # Prices
    target_buy_price: Mapped[float]              = mapped_column(Float)
    target_sell_price: Mapped[float]             = mapped_column(Float)
    actual_buy_price: Mapped[Optional[float]]    = mapped_column(Float, nullable=True)
    actual_sell_price: Mapped[Optional[float]]   = mapped_column(Float, nullable=True)

    # Amounts
    capital_usdt: Mapped[float]                  = mapped_column(Float)
    coin_amount: Mapped[Optional[float]]         = mapped_column(Float, nullable=True)
    received_coins: Mapped[Optional[float]]      = mapped_column(Float, nullable=True)

    # Fees
    buy_fee_usdt: Mapped[float]                  = mapped_column(Float, default=0)
    sell_fee_usdt: Mapped[float]                 = mapped_column(Float, default=0)
    withdrawal_fee_coins: Mapped[float]          = mapped_column(Float, default=0)
    withdrawal_fee_usdt: Mapped[float]           = mapped_column(Float, default=0)
    total_fees_usdt: Mapped[float]               = mapped_column(Float, default=0)

    # Network
    network_used: Mapped[Optional[str]]          = mapped_column(String(50), nullable=True)
    tx_hash: Mapped[Optional[str]]               = mapped_column(String(200), nullable=True)
    deposit_address: Mapped[Optional[str]]       = mapped_column(String(200), nullable=True)

    # Profit
    gross_profit_usdt: Mapped[float]             = mapped_column(Float, default=0)
    net_profit_usdt: Mapped[float]               = mapped_column(Float, default=0)
    net_profit_pct: Mapped[float]                = mapped_column(Float, default=0)

    # Timing
    transfer_time_seconds: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    status: Mapped[str]                          = mapped_column(String(30), default=TradeStatus.PENDING, index=True)
    error_message: Mapped[Optional[str]]         = mapped_column(Text, nullable=True)
    error_step: Mapped[Optional[str]]            = mapped_column(String(50), nullable=True)

    # Exchange order IDs
    buy_order_id: Mapped[Optional[str]]          = mapped_column(String(100), nullable=True)
    sell_order_id: Mapped[Optional[str]]         = mapped_column(String(100), nullable=True)
    withdrawal_id: Mapped[Optional[str]]         = mapped_column(String(100), nullable=True)

    started_at: Mapped[datetime]                 = mapped_column(DateTime, default=datetime.utcnow, index=True)
    completed_at: Mapped[Optional[datetime]]     = mapped_column(DateTime, nullable=True)


class DisabledCoin(Base):
    """Coins excluded from scanning/trading"""
    __tablename__ = "disabled_coins"

    id: Mapped[int]               = mapped_column(Integer, primary_key=True)
    symbol: Mapped[str]           = mapped_column(String(30), unique=True, index=True)
    reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime]  = mapped_column(DateTime, default=datetime.utcnow)


class TradeCooldown(Base):
    """Per-coin cooldown tracker"""
    __tablename__ = "trade_cooldowns"

    id: Mapped[int]          = mapped_column(Integer, primary_key=True)
    symbol: Mapped[str]      = mapped_column(String(30), unique=True, index=True)
    last_trade_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


# ── Init ─────────────────────────────────────────────────────────────────────
async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    # Seed default config
    async with AsyncSessionLocal() as session:
        from sqlalchemy import select
        result = await session.execute(
            select(SystemConfig).where(SystemConfig.key == "min_profit_pct")
        )
        if not result.scalar_one_or_none():
            defaults = [
                SystemConfig(key="min_profit_pct",       value="1.2"),
                SystemConfig(key="max_capital_usdt",     value="120.0"),
                SystemConfig(key="slippage_pct",         value="0.10"),
                SystemConfig(key="max_transfer_min",     value="60"),
                SystemConfig(key="cooldown_seconds",     value="300"),
                SystemConfig(key="arb_mode",             value="transfer"),
                SystemConfig(key="auto_trade_enabled",   value="false"),
                SystemConfig(key="auto_trade_mode",      value="transfer"),
                SystemConfig(key="emergency_stop",       value="false"),
                SystemConfig(key="scanner_active",       value="true"),
                SystemConfig(key="max_concurrent_trades",value="2"),
                SystemConfig(key="auto_min_profit_pct",  value="1.5"),
            ]
            session.add_all(defaults)
            await session.commit()


async def get_db():
    async with AsyncSessionLocal() as session:
        yield session


async def get_config() -> dict:
    async with AsyncSessionLocal() as session:
        from sqlalchemy import select
        result = await session.execute(select(SystemConfig))
        return {r.key: r.value for r in result.scalars().all()}
