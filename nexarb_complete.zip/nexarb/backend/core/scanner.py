"""
ArbitrageScanner — Core price discovery engine
- Scans 30 exchanges asynchronously
- Uses real orderbook top-5 levels for weighted prices
- Fetches real trading fees and withdrawal fees
- Performs network matching
- Calculates accurate net profit
"""

import asyncio
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Tuple

import ccxt.async_support as ccxt
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

from core.config import settings, EXCHANGES
from core.database import AsyncSessionLocal, Opportunity, DisabledCoin, SystemConfig, get_config
from sqlalchemy import select, delete

logger = logging.getLogger("nexarb.scanner")


# ── Data Classes ──────────────────────────────────────────────────────────────

@dataclass
class WeightedPrice:
    """Weighted average price from top-N orderbook levels"""
    price: float          # Weighted average
    top_price: float      # Best single price
    total_volume: float   # Available volume at these levels
    levels_used: int


@dataclass
class CurrencyMeta:
    """Currency capabilities from fetch_currencies()"""
    withdrawal_enabled: bool
    deposit_enabled: bool
    networks: List[str] = field(default_factory=list)
    withdrawal_fees: Dict[str, float] = field(default_factory=dict)   # network → fee in coin
    min_withdrawal: Dict[str, float] = field(default_factory=dict)    # network → min amount
    cached_at: float = field(default_factory=time.time)


@dataclass
class ArbitrageOpportunity:
    symbol: str
    buy_exchange: str
    sell_exchange: str
    buy_price: float          # weighted ask
    sell_price: float         # weighted bid
    network: Optional[str]
    available_networks: List[str]
    buy_fee_pct: float
    sell_fee_pct: float
    withdrawal_fee_usd: float
    withdrawal_fee_pct: float
    slippage_pct: float
    gross_profit_pct: float
    net_profit_pct: float
    network_matched: bool
    withdrawal_ok: bool
    deposit_ok: bool
    status: str               # PROFIT | ACTIVE | WARNING
    warn_reason: Optional[str]
    scanned_at: str


# ── Exchange Client ───────────────────────────────────────────────────────────

class ExchangeClient:
    """Wrapper around a single ccxt exchange with caching and retry"""

    def __init__(self, exchange_id: str, api_key=None, secret=None, passphrase=None):
        self.exchange_id = exchange_id
        self._api_key = api_key
        self._secret = secret
        self._passphrase = passphrase
        self.client: Optional[ccxt.Exchange] = None
        self.markets: Dict = {}
        self.currency_cache: Dict[str, CurrencyMeta] = {}
        self.fee_rate: float = 0.001
        self.last_error: Optional[str] = None
        self.connected: bool = False
        self._lock = asyncio.Lock()

    async def connect(self) -> bool:
        cfg = {
            "enableRateLimit": True,
            "timeout": settings.REQUEST_TIMEOUT_MS,
            "options": {"defaultType": "spot"},
        }
        if self._api_key:
            cfg["apiKey"] = self._api_key
            cfg["secret"] = self._secret
            if self._passphrase:
                cfg["password"] = self._passphrase

        try:
            cls = getattr(ccxt, self.exchange_id, None)
            if cls is None:
                raise ValueError(f"Exchange {self.exchange_id} not found in ccxt")
            self.client = cls(cfg)
            self.connected = True
            return True
        except Exception as e:
            self.last_error = str(e)
            logger.warning(f"[{self.exchange_id}] connect failed: {e}")
            return False

    async def load_markets(self) -> bool:
        if not self.client:
            await self.connect()
        try:
            self.markets = await self.client.load_markets()
            # Extract taker fee
            fees = getattr(self.client, "fees", {}) or {}
            self.fee_rate = fees.get("trading", {}).get("taker", 0.001)
            return True
        except Exception as e:
            self.last_error = str(e)
            logger.debug(f"[{self.exchange_id}] load_markets: {e}")
            return False

    def get_usdt_pairs(self) -> List[str]:
        return [
            s for s, m in self.markets.items()
            if "/USDT" in s
            and m.get("active", True)
            and m.get("spot", True)
            and not m.get("margin", False)
        ]

    async def get_weighted_prices(self, symbol: str, capital: float = 120.0) -> Optional[Tuple[WeightedPrice, WeightedPrice]]:
        """Returns (weighted_ask, weighted_bid) using top-5 orderbook levels"""
        if not self.client:
            return None
        try:
            ob = await self.client.fetch_order_book(symbol, limit=settings.ORDERBOOK_DEPTH)
            asks = ob.get("asks", [])
            bids = ob.get("bids", [])
            if not asks or not bids:
                return None

            def weighted(levels, budget):
                total_cost = 0.0
                total_qty  = 0.0
                remaining  = budget
                for price, qty in levels[:settings.ORDERBOOK_DEPTH]:
                    if price <= 0:
                        continue
                    can_buy = min(remaining / price, qty)
                    total_cost += can_buy * price
                    total_qty  += can_buy
                    remaining  -= can_buy * price
                    if remaining <= 0:
                        break
                if total_qty == 0:
                    return None
                return WeightedPrice(
                    price=total_cost / total_qty,
                    top_price=levels[0][0],
                    total_volume=sum(l[1] for l in levels[:5]),
                    levels_used=min(len(levels), 5),
                )

            ask_wp = weighted(asks, capital)
            bid_wp = weighted(bids, capital)
            if not ask_wp or not bid_wp:
                return None
            return ask_wp, bid_wp
        except Exception:
            return None

    async def get_currency_meta(self, coin: str) -> Optional[CurrencyMeta]:
        """Fetch withdrawal/deposit status and network fees (cached)"""
        # Return cached if fresh
        cached = self.currency_cache.get(coin)
        if cached and (time.time() - cached.cached_at) < settings.CACHE_TTL_SECONDS:
            return cached

        if not self.client:
            return None
        try:
            async with self._lock:
                # Double-check after acquiring lock
                cached = self.currency_cache.get(coin)
                if cached and (time.time() - cached.cached_at) < settings.CACHE_TTL_SECONDS:
                    return cached

                currencies = await self.client.fetch_currencies()
                if coin not in currencies:
                    return None

                cur = currencies[coin]
                meta = CurrencyMeta(
                    withdrawal_enabled=bool(cur.get("withdraw", False)),
                    deposit_enabled=bool(cur.get("deposit", False)),
                )

                # Parse networks
                networks = cur.get("networks", {}) or {}
                for net_id, net_data in networks.items():
                    if not isinstance(net_data, dict):
                        continue
                    net_name = (net_data.get("id") or net_id).upper()

                    # Only include networks where withdrawal is allowed
                    if not net_data.get("withdraw", True):
                        continue

                    meta.networks.append(net_name)

                    fee = net_data.get("fee") or 0
                    meta.withdrawal_fees[net_name] = float(fee)

                    limits = net_data.get("limits", {}) or {}
                    min_w = (limits.get("withdraw") or {}).get("min") or 0
                    meta.min_withdrawal[net_name] = float(min_w)

                # Fallback if no network data
                if not meta.networks and meta.withdrawal_enabled:
                    fee = float(cur.get("fee") or 0)
                    meta.networks = ["DEFAULT"]
                    meta.withdrawal_fees["DEFAULT"] = fee

                self.currency_cache[coin] = meta
                return meta
        except Exception as e:
            logger.debug(f"[{self.exchange_id}] fetch_currencies {coin}: {e}")
            return None

    async def get_trading_fee(self, symbol: str) -> Tuple[float, float]:
        """Returns (maker_pct, taker_pct). Falls back to exchange default."""
        try:
            if self.client and hasattr(self.client, "fetch_trading_fee"):
                info = await self.client.fetch_trading_fee(symbol)
                maker = float(info.get("maker", self.fee_rate)) * 100
                taker = float(info.get("taker", self.fee_rate)) * 100
                return maker, taker
        except Exception:
            pass
        return self.fee_rate * 100, self.fee_rate * 100

    async def close(self):
        if self.client:
            try:
                await self.client.close()
            except Exception:
                pass


# ── Scanner ───────────────────────────────────────────────────────────────────

class ArbitrageScanner:
    """Continuously scans 30 exchanges for arbitrage opportunities"""

    def __init__(self):
        self.running: bool = False
        self._stop = asyncio.Event()
        self.clients: Dict[str, ExchangeClient] = {}
        self.opportunities: List[dict] = []
        self.stats = {
            "exchanges_active": 0,
            "pairs_scanned": 0,
            "matched_opportunities": 0,
            "best_profit_pct": 0.0,
            "best_profit_usd": 0.0,
            "total_profit_opportunities": 0,
            "last_scan_ts": None,
            "scan_duration_ms": 0,
        }
        self._initialized = False

    def stop(self):
        self._stop.set()
        self.running = False

    # ── Initialization ────────────────────────────────────────────────────────

    async def _init_clients(self):
        """Initialize all exchange clients, loading API keys from DB"""
        from utils.crypto import decrypt_value

        # Load keys from DB
        async with AsyncSessionLocal() as session:
            result = await session.execute(
                select(ExchangeClient).limit(0)  # just to warm connection
            )

        async with AsyncSessionLocal() as session:
            from core.database import ExchangeKey
            result = await session.execute(
                select(ExchangeKey).where(ExchangeKey.is_enabled == True)
            )
            db_keys = {k.exchange_id: k for k in result.scalars().all()}

        tasks = []
        for ex_id in EXCHANGES:
            db_key = db_keys.get(ex_id)
            if db_key:
                client = ExchangeClient(
                    ex_id,
                    api_key=decrypt_value(db_key.api_key_enc),
                    secret=decrypt_value(db_key.api_secret_enc),
                    passphrase=decrypt_value(db_key.api_pass_enc) if db_key.api_pass_enc else None,
                )
            else:
                client = ExchangeClient(ex_id)  # public/read-only
            self.clients[ex_id] = client
            tasks.append(client.load_markets())

        results = await asyncio.gather(*tasks, return_exceptions=True)
        active = sum(1 for r in results if r is True)
        logger.info(f"Markets loaded: {active}/{len(EXCHANGES)} exchanges active")
        self._initialized = True

    # ── Main scan ─────────────────────────────────────────────────────────────

    async def scan_once(self):
        config = await get_config()

        if config.get("emergency_stop", "false") == "true":
            logger.warning("Emergency stop active — skipping scan")
            return

        if config.get("scanner_active", "true") != "true":
            return

        min_profit  = float(config.get("min_profit_pct", 1.2))
        capital     = float(config.get("max_capital_usdt", 120.0))
        slippage    = float(config.get("slippage_pct", 0.10))

        t_start = time.time()

        # Collect disabled coins
        disabled_coins = await self._get_disabled_coins()

        # Refresh client list periodically
        if not self._initialized:
            await self._init_clients()

        # Collect USDT pairs per exchange
        exchange_pairs: Dict[str, List[str]] = {}
        active_count = 0
        for ex_id, client in self.clients.items():
            pairs = client.get_usdt_pairs()
            if pairs:
                exchange_pairs[ex_id] = pairs
                active_count += 1

        self.stats["exchanges_active"] = active_count

        # Build pair → [exchanges] map
        pair_map: Dict[str, List[str]] = {}
        for ex_id, pairs in exchange_pairs.items():
            for p in pairs:
                pair_map.setdefault(p, []).append(ex_id)

        # Only pairs on 2+ exchanges
        multi_pairs = {p: exs for p, exs in pair_map.items() if len(exs) >= 2}
        self.stats["pairs_scanned"] = len(multi_pairs)

        # Scan in batches
        all_opps: List[ArbitrageOpportunity] = []
        pair_list = list(multi_pairs.items())[:settings.MAX_PAIRS_PER_SCAN]

        for i in range(0, len(pair_list), settings.BATCH_SIZE):
            batch = pair_list[i : i + settings.BATCH_SIZE]
            batch_opps = await self._scan_batch(batch, disabled_coins, capital, slippage)
            all_opps.extend(batch_opps)
            await asyncio.sleep(0.05)  # breathing room for rate limits

        # Sort by net profit descending
        all_opps.sort(key=lambda x: x.net_profit_pct, reverse=True)

        # Convert to dicts for JSON serialization
        self.opportunities = [self._opp_to_dict(o) for o in all_opps]

        # Update stats
        profit_opps = [o for o in all_opps if o.status == "PROFIT"]
        best = all_opps[0] if all_opps else None
        self.stats.update({
            "matched_opportunities": len(profit_opps),
            "total_profit_opportunities": len(profit_opps),
            "best_profit_pct": round(best.net_profit_pct, 4) if best else 0.0,
            "best_profit_usd": round(capital * (best.net_profit_pct / 100), 2) if best else 0.0,
            "last_scan_ts": datetime.utcnow().isoformat(),
            "scan_duration_ms": int((time.time() - t_start) * 1000),
        })

        # Persist top 100 to DB
        await self._persist_opportunities(self.opportunities[:100])

    async def _scan_batch(
        self,
        batch: List[Tuple[str, List[str]]],
        disabled_coins: set,
        capital: float,
        slippage: float,
    ) -> List[ArbitrageOpportunity]:

        results = []
        for symbol, exchanges in batch:
            coin = symbol.split("/")[0]
            if coin in disabled_coins:
                continue

            # Fetch orderbooks concurrently
            ob_tasks = {
                ex_id: self.clients[ex_id].get_weighted_prices(symbol, capital)
                for ex_id in exchanges
                if ex_id in self.clients
            }
            ob_results = await asyncio.gather(*ob_tasks.values(), return_exceptions=True)
            prices: Dict[str, Tuple[WeightedPrice, WeightedPrice]] = {}
            for ex_id, res in zip(ob_tasks.keys(), ob_results):
                if isinstance(res, tuple) and res is not None:
                    prices[ex_id] = res

            if len(prices) < 2:
                continue

            # Find best buy (lowest weighted ask) and best sell (highest weighted bid)
            sorted_ask = sorted(prices.items(), key=lambda x: x[1][0].price)
            sorted_bid = sorted(prices.items(), key=lambda x: x[1][1].price, reverse=True)

            buy_ex = sorted_ask[0][0]
            # Best sell must be a different exchange
            sell_ex = None
            for ex_id, _ in sorted_bid:
                if ex_id != buy_ex:
                    sell_ex = ex_id
                    break

            if not sell_ex:
                continue

            buy_price  = prices[buy_ex][0].price    # weighted ask
            sell_price = prices[sell_ex][1].price   # weighted bid

            if buy_price <= 0:
                continue

            # Get real trading fees
            buy_fee_task  = self.clients[buy_ex].get_trading_fee(symbol)
            sell_fee_task = self.clients[sell_ex].get_trading_fee(symbol)
            (_, buy_taker), (_, sell_taker) = await asyncio.gather(buy_fee_task, sell_fee_task)

            # Get currency meta for network matching
            buy_meta, sell_meta = await asyncio.gather(
                self.clients[buy_ex].get_currency_meta(coin),
                self.clients[sell_ex].get_currency_meta(coin),
                return_exceptions=True,
            )

            # Network matching
            network_matched = False
            best_network    = None
            wd_fee_coins    = 0.0
            wd_fee_usd      = 0.0
            wd_fee_pct      = 0.0
            withdrawal_ok   = False
            deposit_ok      = False
            matched_networks = []
            warn_reason     = None

            if isinstance(buy_meta, CurrencyMeta) and isinstance(sell_meta, CurrencyMeta):
                withdrawal_ok = buy_meta.withdrawal_enabled
                deposit_ok    = sell_meta.deposit_enabled

                if not withdrawal_ok:
                    warn_reason = "WITHDRAWAL DISABLED"
                elif not deposit_ok:
                    warn_reason = "DEPOSIT DISABLED"
                else:
                    buy_nets  = set(buy_meta.networks)
                    sell_nets = set(sell_meta.networks)
                    intersection = buy_nets & sell_nets
                    matched_networks = sorted(intersection)

                    if intersection:
                        # Pick network with lowest withdrawal fee
                        best_network = min(
                            intersection,
                            key=lambda n: buy_meta.withdrawal_fees.get(n, 999),
                        )
                        wd_fee_coins = buy_meta.withdrawal_fees.get(best_network, 0)
                        wd_fee_usd   = wd_fee_coins * buy_price
                        wd_fee_pct   = (wd_fee_usd / capital) * 100
                        network_matched = True
                    else:
                        warn_reason = "NO NETWORK MATCH"
            else:
                warn_reason = "FEE DATA UNAVAILABLE"

            # ── Profit Calculation ──────────────────────────────────────────
            # capital           → buy_amount coins
            # buy_amount        = capital / buy_price
            # buy_fee_usdt      = capital × buy_taker_pct
            # after_wd_coins    = buy_amount − wd_fee_coins
            # sell_proceeds     = after_wd_coins × sell_price
            # sell_fee_usdt     = sell_proceeds × sell_taker_pct
            # net_profit        = sell_proceeds − sell_fee − capital − buy_fee − (wd_fee already deducted)

            buy_amount       = capital / buy_price
            buy_fee_usdt     = capital * (buy_taker / 100)
            after_wd_coins   = buy_amount - wd_fee_coins
            sell_proceeds    = after_wd_coins * sell_price
            sell_fee_usdt    = sell_proceeds * (sell_taker / 100)
            slip_usdt        = capital * (slippage / 100)

            gross_pct = ((sell_price - buy_price) / buy_price) * 100
            net_profit_usdt  = (
                sell_proceeds
                - sell_fee_usdt
                - capital
                - buy_fee_usdt
                - slip_usdt
            )
            net_profit_pct   = (net_profit_usdt / capital) * 100

            # Status
            if not network_matched or not withdrawal_ok or not deposit_ok:
                status = "WARNING"
            elif net_profit_pct >= float(await self._get_min_profit()):
                status = "PROFIT"
            else:
                status = "ACTIVE"

            results.append(ArbitrageOpportunity(
                symbol=symbol,
                buy_exchange=buy_ex,
                sell_exchange=sell_ex,
                buy_price=round(buy_price, 8),
                sell_price=round(sell_price, 8),
                network=best_network,
                available_networks=matched_networks,
                buy_fee_pct=round(buy_taker, 4),
                sell_fee_pct=round(sell_taker, 4),
                withdrawal_fee_usd=round(wd_fee_usd, 4),
                withdrawal_fee_pct=round(wd_fee_pct, 4),
                slippage_pct=slippage,
                gross_profit_pct=round(gross_pct, 4),
                net_profit_pct=round(net_profit_pct, 4),
                network_matched=network_matched,
                withdrawal_ok=withdrawal_ok,
                deposit_ok=deposit_ok,
                status=status,
                warn_reason=warn_reason,
                scanned_at=datetime.utcnow().isoformat(),
            ))

        return results

    _min_profit_cache: float = 1.2
    _min_profit_ts: float = 0

    async def _get_min_profit(self) -> float:
        if time.time() - self._min_profit_ts > 30:
            cfg = await get_config()
            self._min_profit_cache = float(cfg.get("min_profit_pct", 1.2))
            self._min_profit_ts = time.time()
        return self._min_profit_cache

    async def _get_disabled_coins(self) -> set:
        async with AsyncSessionLocal() as session:
            result = await session.execute(select(DisabledCoin.symbol))
            return {r[0] for r in result.all()}

    def _opp_to_dict(self, o: ArbitrageOpportunity) -> dict:
        return {
            "symbol": o.symbol,
            "buy_exchange": o.buy_exchange,
            "sell_exchange": o.sell_exchange,
            "buy_price": o.buy_price,
            "sell_price": o.sell_price,
            "network": o.network,
            "available_networks": o.available_networks,
            "buy_fee_pct": o.buy_fee_pct,
            "sell_fee_pct": o.sell_fee_pct,
            "withdrawal_fee_usd": o.withdrawal_fee_usd,
            "withdrawal_fee_pct": o.withdrawal_fee_pct,
            "slippage_pct": o.slippage_pct,
            "gross_profit_pct": o.gross_profit_pct,
            "net_profit_pct": o.net_profit_pct,
            "network_matched": o.network_matched,
            "withdrawal_ok": o.withdrawal_ok,
            "deposit_ok": o.deposit_ok,
            "status": o.status,
            "warn_reason": o.warn_reason,
            "scanned_at": o.scanned_at,
        }

    async def _persist_opportunities(self, opps: List[dict]):
        async with AsyncSessionLocal() as session:
            await session.execute(delete(Opportunity))
            for o in opps:
                session.add(Opportunity(
                    symbol=o["symbol"],
                    buy_exchange=o["buy_exchange"],
                    sell_exchange=o["sell_exchange"],
                    buy_price=o["buy_price"],
                    sell_price=o["sell_price"],
                    network=o.get("network"),
                    available_networks={"networks": o.get("available_networks", [])},
                    buy_fee_pct=o["buy_fee_pct"],
                    sell_fee_pct=o["sell_fee_pct"],
                    withdrawal_fee_usd=o["withdrawal_fee_usd"],
                    withdrawal_fee_pct=o["withdrawal_fee_pct"],
                    slippage_pct=o["slippage_pct"],
                    gross_profit_pct=o["gross_profit_pct"],
                    net_profit_pct=o["net_profit_pct"],
                    network_matched=o["network_matched"],
                    withdrawal_ok=o["withdrawal_ok"],
                    deposit_ok=o["deposit_ok"],
                    status=o["status"],
                    warn_reason=o.get("warn_reason"),
                ))
            await session.commit()

    # ── Forever loop ──────────────────────────────────────────────────────────

    async def run_forever(self):
        self.running = True
        logger.info("Scanner started")

        if not self._initialized:
            await self._init_clients()

        while not self._stop.is_set():
            try:
                await self.scan_once()
            except Exception as e:
                logger.error(f"Scan error: {e}", exc_info=True)

            try:
                await asyncio.wait_for(
                    self._stop.wait(),
                    timeout=settings.SCAN_INTERVAL_SECONDS
                )
            except asyncio.TimeoutError:
                pass

        # Cleanup
        for client in self.clients.values():
            await client.close()

        self.running = False
        logger.info("Scanner stopped")
