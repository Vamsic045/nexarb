"""
NEXARB — Crypto Arbitrage System
Main FastAPI Application Entry Point
"""

import asyncio
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse

from core.config import settings
from core.database import init_db
from core.scanner import ArbitrageScanner
from core.auto_trader import AutoTrader
from api.routes import router as api_router

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("nexarb")

# Global instances
scanner: ArbitrageScanner = None
auto_trader: AutoTrader = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global scanner, auto_trader

    logger.info("=" * 60)
    logger.info("  NEXARB Arbitrage System Starting...")
    logger.info("=" * 60)

    # Initialize database
    logger.info("Initializing database...")
    await init_db()

    # Start scanner
    logger.info("Starting arbitrage scanner (30 exchanges)...")
    scanner = ArbitrageScanner()
    asyncio.create_task(scanner.run_forever())

    # Start auto-trader (monitors scanner, fires trades automatically)
    logger.info("Starting auto-trader engine...")
    auto_trader = AutoTrader(scanner)
    asyncio.create_task(auto_trader.run_forever())

    # Attach to app state
    app.state.scanner = scanner
    app.state.auto_trader = auto_trader

    logger.info("System ready.")
    yield

    # Graceful shutdown
    logger.info("Shutting down...")
    if scanner:
        scanner.stop()
    if auto_trader:
        auto_trader.stop()


app = FastAPI(
    title="NEXARB Arbitrage System",
    version="2.0.0",
    docs_url="/api/docs" if settings.DEBUG else None,
    redoc_url=None,
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# API routes
app.include_router(api_router, prefix="/api")

# Static files
app.mount("/static", StaticFiles(directory="frontend/static"), name="static")


@app.get("/")
async def dashboard():
    return FileResponse("frontend/index.html")


@app.get("/health")
async def health(request: Request):
    sc = request.app.state.scanner
    at = request.app.state.auto_trader
    return {
        "status": "ok",
        "scanner_running": sc.running if sc else False,
        "auto_trader_running": at.running if at else False,
        "auto_trade_enabled": at.enabled if at else False,
        "opportunities_count": len(sc.opportunities) if sc else 0,
    }


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"error": "Internal server error", "detail": str(exc)},
    )
