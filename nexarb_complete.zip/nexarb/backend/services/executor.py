"""
TradeExecutor — Executes arbitrage trades
Supports:
  - Transfer Arbitrage: Buy → Withdraw → Wait → Re-check → Sell
  - Simultaneous Arbitrage: Buy + Sell at same time
"""

import asyncio
import logging
from datetime import datetime
from typing import Dict, Optional, TYPE_CHECKING

from core.database import (
    AsyncSessionLocal, Trade, TradeStatus, ArbMode, ExecMode, get_config
)
from sqlalchemy import select

if TYPE_CHECKING:
    from core.scanner import ExchangeClient

logger = logging.getLogger("nexarb.executor")


class TradeExecutor:

    def __init__(self, clients: Dict[str, "ExchangeClient"]):
        self.clients = clients

    async def execute(
        self,
        opp: dict,
        capital: float,
        config: dict,
        exec_mode: str = "manual",
    ) -> int:
        """Create trade record, spawn execution task, return trade_id"""
        arb_mode = config.get("arb_mode", "transfer")

        async with AsyncSessionLocal() as session:
            trade = Trade(
                exec_mode=exec_mode,
                arb_mode=arb_mode,
                symbol=opp["symbol"],
                buy_exchange=opp["buy_exchange"],
                sell_exchange=opp["sell_exchange"],
                target_buy_price=opp["buy_price"],
                target_sell_price=opp["sell_price"],
                capital_usdt=capital,
                network_used=opp.get("network"),
                status=TradeStatus.PENDING,
            )
            session.add(trade)
            await session.commit()
            await session.refresh(trade)
            trade_id = trade.id

        logger.info(
            f"[Trade #{trade_id}] Created | {opp['symbol']} | "
            f"{opp['buy_exchange']}→{opp['sell_exchange']} | "
            f"mode={arb_mode} | exec={exec_mode} | capital=${capital}"
        )

        if arb_mode == ArbMode.TRANSFER:
            asyncio.create_task(
                self._run_transfer(trade_id, opp, capital, config)
            )
        else:
            asyncio.create_task(
                self._run_simultaneous(trade_id, opp, capital, config)
            )

        return trade_id

    # ── Helpers ───────────────────────────────────────────────────────────────

    async def _update(self, trade_id: int, **kwargs):
        async with AsyncSessionLocal() as session:
            result = await session.execute(
                select(Trade).where(Trade.id == trade_id)
            )
            trade = result.scalar_one_or_none()
            if trade:
                for k, v in kwargs.items():
                    setattr(trade, k, v)
                await session.commit()

    async def _fail(self, trade_id: int, step: str, msg: str):
        logger.error(f"[Trade #{trade_id}] FAILED at {step}: {msg}")
        await self._update(
            trade_id,
            status=TradeStatus.FAILED,
            error_step=step,
            error_message=msg,
            completed_at=datetime.utcnow(),
        )

    def _get_client(self, exchange_id: str):
        client = self.clients.get(exchange_id)
        if not client or not client.client:
            raise RuntimeError(f"No active client for exchange: {exchange_id}")
        return client

    # ── Transfer Arbitrage ────────────────────────────────────────────────────

    async def _run_transfer(self, trade_id: int, opp: dict, capital: float, config: dict):
        """
        Transfer Arbitrage flow:
        1. Buy on ExA
        2. Get deposit address from ExB
        3. Withdraw from ExA → ExB
        4. Poll for deposit confirmation
        5. Re-check sell price
        6. Sell on ExB (market or limit)
        """
        symbol     = opp["symbol"]
        coin       = symbol.split("/")[0]
        buy_ex_id  = opp["buy_exchange"]
        sell_ex_id = opp["sell_exchange"]
        network    = opp.get("network")
        min_profit = float(config.get("min_profit_pct", 1.2))
        max_wait   = int(config.get("max_transfer_min", 60)) * 60

        try:
            buy_client  = self._get_client(buy_ex_id)
            sell_client = self._get_client(sell_ex_id)

            # ── Step 1: BUY ───────────────────────────────────────────────
            await self._update(trade_id, status=TradeStatus.BUYING)
            logger.info(f"[Trade #{trade_id}] Step 1: Buying {symbol} on {buy_ex_id}")

            buy_amount = capital / opp["buy_price"]
            buy_order = await buy_client.client.create_market_buy_order(
                symbol, buy_amount
            )

            actual_buy_price = float(buy_order.get("average") or opp["buy_price"])
            buy_fee_usdt     = float((buy_order.get("fee") or {}).get("cost") or
                                      capital * (opp["buy_fee_pct"] / 100))
            actual_coins     = float(buy_order.get("filled") or buy_amount)
            buy_order_id     = str(buy_order.get("id", ""))

            logger.info(
                f"[Trade #{trade_id}] Bought {actual_coins:.6f} {coin} "
                f"@ ${actual_buy_price:.4f} | fee=${buy_fee_usdt:.4f}"
            )

            await self._update(
                trade_id,
                actual_buy_price=actual_buy_price,
                buy_fee_usdt=buy_fee_usdt,
                coin_amount=actual_coins,
                buy_order_id=buy_order_id,
                status=TradeStatus.WITHDRAWING,
            )

            # ── Step 2: GET DEPOSIT ADDRESS ───────────────────────────────
            params = {}
            if network:
                params["network"] = network

            dep_info = await sell_client.client.fetch_deposit_address(coin, params=params)
            dep_addr = dep_info.get("address")
            dep_tag  = dep_info.get("tag")

            if not dep_addr:
                await self._fail(trade_id, "get_deposit_address", "No deposit address returned")
                return

            await self._update(trade_id, deposit_address=dep_addr)
            logger.info(f"[Trade #{trade_id}] Deposit address: {dep_addr[:20]}...")

            # ── Step 3: WITHDRAW ──────────────────────────────────────────
            logger.info(f"[Trade #{trade_id}] Step 3: Withdrawing {actual_coins:.6f} {coin} via {network}")
            wd_params = {}
            if network:
                wd_params["network"] = network
            if dep_tag:
                wd_params["tag"] = dep_tag

            # Subtract withdrawal fee from amount
            wd_fee_coins = opp.get("withdrawal_fee_usd", 0) / actual_buy_price
            send_amount  = actual_coins - wd_fee_coins * 1.05  # 5% buffer

            wd_result  = await buy_client.client.withdraw(
                coin, send_amount, dep_addr, params=wd_params
            )
            tx_hash    = str(wd_result.get("id") or wd_result.get("txid") or "")
            wd_fee_usd = wd_fee_coins * actual_buy_price

            await self._update(
                trade_id,
                tx_hash=tx_hash,
                withdrawal_fee_coins=wd_fee_coins,
                withdrawal_fee_usdt=wd_fee_usd,
                status=TradeStatus.WAITING_DEPOSIT,
            )
            logger.info(f"[Trade #{trade_id}] Withdrawal submitted | tx={tx_hash[:20]}...")

            # ── Step 4: WAIT FOR DEPOSIT ──────────────────────────────────
            logger.info(f"[Trade #{trade_id}] Step 4: Waiting for deposit on {sell_ex_id}")
            start_wait   = datetime.utcnow()
            deposit_amount = 0.0

            while True:
                elapsed = (datetime.utcnow() - start_wait).total_seconds()
                if elapsed > max_wait:
                    await self._fail(
                        trade_id, "wait_deposit",
                        f"Deposit timeout after {max_wait//60} minutes"
                    )
                    return

                try:
                    deposits = await sell_client.client.fetch_deposits(coin, limit=20)
                    for dep in deposits:
                        dep_tx = str(dep.get("txid") or "")
                        dep_st = dep.get("status", "")
                        if (dep_tx == tx_hash or dep_st in ("ok", "confirmed")) and \
                           float(dep.get("amount", 0)) > 0:
                            deposit_amount = float(dep["amount"])
                            break
                    if deposit_amount > 0:
                        break
                except Exception as e:
                    logger.debug(f"[Trade #{trade_id}] deposit poll error: {e}")

                await asyncio.sleep(30)

            transfer_secs = int((datetime.utcnow() - start_wait).total_seconds())
            logger.info(
                f"[Trade #{trade_id}] Deposit confirmed: {deposit_amount:.6f} {coin} "
                f"in {transfer_secs}s"
            )

            # ── Step 5: RE-CHECK PRICE ────────────────────────────────────
            await self._update(
                trade_id,
                status=TradeStatus.RECHECKING,
                transfer_time_seconds=transfer_secs,
            )

            current_prices = await sell_client.get_weighted_prices(symbol, capital)
            if not current_prices:
                await self._fail(trade_id, "recheck_price", "Cannot fetch current sell price")
                return

            current_sell = current_prices[1].price   # weighted bid
            sell_fee_pct = opp["sell_fee_pct"]

            # Recalculate net profit with current sell price
            current_gross = ((current_sell - actual_buy_price) / actual_buy_price) * 100
            current_net   = (
                current_gross
                - opp["buy_fee_pct"]
                - sell_fee_pct
                - opp.get("withdrawal_fee_pct", 0)
                - opp["slippage_pct"]
            )

            logger.info(
                f"[Trade #{trade_id}] Recheck: sell=${current_sell:.4f} "
                f"net={current_net:.2f}% (threshold={min_profit}%)"
            )

            # ── Step 6: SELL ──────────────────────────────────────────────
            await self._update(trade_id, status=TradeStatus.SELLING)

            if current_net >= min_profit:
                # Price still good → market sell
                sell_order = await sell_client.client.create_market_sell_order(
                    symbol, deposit_amount
                )
                logger.info(f"[Trade #{trade_id}] Market sell executed")
            else:
                # Price dropped → place limit sell at minimum profitable price
                min_sell_price = actual_buy_price * (
                    1 + (min_profit + sell_fee_pct + opp["buy_fee_pct"]) / 100
                )
                logger.info(
                    f"[Trade #{trade_id}] Price dropped → limit sell at ${min_sell_price:.4f}"
                )
                sell_order = await sell_client.client.create_limit_sell_order(
                    symbol, deposit_amount, min_sell_price
                )
                await self._update(
                    trade_id,
                    sell_order_id=str(sell_order.get("id", "")),
                    actual_sell_price=min_sell_price,
                    status=TradeStatus.LIMIT_PLACED,
                )
                return

            actual_sell_price = float(sell_order.get("average") or current_sell)
            sell_fee_usdt     = float((sell_order.get("fee") or {}).get("cost") or
                                       deposit_amount * actual_sell_price * (sell_fee_pct / 100))
            sell_order_id     = str(sell_order.get("id", ""))

            # ── Final P&L ─────────────────────────────────────────────────
            sell_proceeds    = deposit_amount * actual_sell_price
            total_fees       = buy_fee_usdt + sell_fee_usdt + wd_fee_usd
            gross_profit     = sell_proceeds - capital
            net_profit_usdt  = gross_profit - total_fees
            net_profit_pct   = (net_profit_usdt / capital) * 100

            await self._update(
                trade_id,
                actual_sell_price=actual_sell_price,
                sell_fee_usdt=sell_fee_usdt,
                sell_order_id=sell_order_id,
                received_coins=deposit_amount,
                total_fees_usdt=total_fees,
                gross_profit_usdt=gross_profit,
                net_profit_usdt=net_profit_usdt,
                net_profit_pct=net_profit_pct,
                status=TradeStatus.COMPLETED,
                completed_at=datetime.utcnow(),
            )

            logger.info(
                f"[Trade #{trade_id}] ✓ COMPLETED | "
                f"net=${net_profit_usdt:.2f} ({net_profit_pct:.2f}%) | "
                f"fees=${total_fees:.2f} | transfer={transfer_secs}s"
            )

            # Telegram notification
            await self._notify(
                f"✓ Trade #{trade_id} completed\n"
                f"{symbol} | {buy_ex_id}→{sell_ex_id}\n"
                f"Net: +${net_profit_usdt:.2f} (+{net_profit_pct:.2f}%)"
            )

        except Exception as e:
            await self._fail(trade_id, "unknown", str(e))

    # ── Simultaneous Arbitrage ────────────────────────────────────────────────

    async def _run_simultaneous(self, trade_id: int, opp: dict, capital: float, config: dict):
        """
        Simultaneous mode: fire buy + sell orders at same time.
        Requires pre-funded accounts on both exchanges.
        """
        symbol     = opp["symbol"]
        buy_ex_id  = opp["buy_exchange"]
        sell_ex_id = opp["sell_exchange"]

        try:
            buy_client  = self._get_client(buy_ex_id)
            sell_client = self._get_client(sell_ex_id)

            await self._update(trade_id, status=TradeStatus.BUYING)
            logger.info(f"[Trade #{trade_id}] Simultaneous: {symbol} | {buy_ex_id}↔{sell_ex_id}")

            amount = capital / opp["buy_price"]

            # Fire both simultaneously
            buy_order, sell_order = await asyncio.gather(
                buy_client.client.create_market_buy_order(symbol, amount),
                sell_client.client.create_market_sell_order(symbol, amount),
            )

            actual_buy  = float(buy_order.get("average") or opp["buy_price"])
            actual_sell = float(sell_order.get("average") or opp["sell_price"])
            buy_fee     = float((buy_order.get("fee") or {}).get("cost") or
                                 capital * (opp["buy_fee_pct"] / 100))
            sell_fee    = float((sell_order.get("fee") or {}).get("cost") or
                                 amount * actual_sell * (opp["sell_fee_pct"] / 100))

            total_fees  = buy_fee + sell_fee
            gross       = (actual_sell - actual_buy) * amount
            net_profit  = gross - total_fees
            net_pct     = (net_profit / capital) * 100

            await self._update(
                trade_id,
                actual_buy_price=actual_buy,
                actual_sell_price=actual_sell,
                buy_fee_usdt=buy_fee,
                sell_fee_usdt=sell_fee,
                total_fees_usdt=total_fees,
                gross_profit_usdt=gross,
                net_profit_usdt=net_profit,
                net_profit_pct=net_pct,
                status=TradeStatus.COMPLETED,
                completed_at=datetime.utcnow(),
            )

            logger.info(
                f"[Trade #{trade_id}] ✓ SIMULTANEOUS COMPLETED | "
                f"net=${net_profit:.2f} ({net_pct:.2f}%)"
            )

            await self._notify(
                f"✓ Simultaneous Trade #{trade_id}\n"
                f"{symbol} | {buy_ex_id}↔{sell_ex_id}\n"
                f"Net: +${net_profit:.2f} (+{net_pct:.2f}%)"
            )

        except Exception as e:
            await self._fail(trade_id, "simultaneous", str(e))

    # ── Notifications ─────────────────────────────────────────────────────────

    async def _notify(self, message: str):
        from core.config import settings
        if not settings.TELEGRAM_BOT_TOKEN or not settings.TELEGRAM_CHAT_ID:
            return
        try:
            import aiohttp
            url = f"https://api.telegram.org/bot{settings.TELEGRAM_BOT_TOKEN}/sendMessage"
            async with aiohttp.ClientSession() as session:
                await session.post(url, json={
                    "chat_id": settings.TELEGRAM_CHAT_ID,
                    "text": message,
                    "parse_mode": "HTML",
                })
        except Exception as e:
            logger.debug(f"Telegram notify failed: {e}")
