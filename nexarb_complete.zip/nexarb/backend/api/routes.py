"""
API Routes — All endpoints
Public: /api/opportunities, /api/stats, /api/ticker
Auth:   /api/auth/login
Admin:  /api/admin/* (JWT required)
"""

import logging
from datetime import datetime
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.security import OAuth2PasswordRequestForm, OAuth2PasswordBearer
from pydantic import BaseModel
from sqlalchemy import select, delete, desc

from core.database import (
    AsyncSessionLocal, SystemConfig, ExchangeKey, Trade, DisabledCoin,
    TradeStatus, get_config
)
from core.config import settings, EXCHANGES
from utils.auth import create_token, verify_token, hash_password, verify_password
from utils.crypto import encrypt_value, decrypt_value

logger = logging.getLogger("nexarb.api")
router = APIRouter()
oauth2 = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


def require_admin(token: str = Depends(oauth2)):
    payload = verify_token(token)
    if payload.get("role") != "admin":
        raise HTTPException(403, "Admin only")
    return payload


# ══════════════════════════════════════════════════════════════════════════════
# PUBLIC ENDPOINTS
# ══════════════════════════════════════════════════════════════════════════════

@router.get("/opportunities")
async def get_opportunities(request: Request):
    sc = request.app.state.scanner
    return {
        "opportunities": sc.opportunities if sc else [],
        "stats": sc.stats if sc else {},
        "auto_trade_enabled": request.app.state.auto_trader.enabled
                               if request.app.state.auto_trader else False,
    }


@router.get("/stats")
async def get_stats(request: Request):
    sc = request.app.state.scanner
    at = request.app.state.auto_trader
    return {
        **(sc.stats if sc else {}),
        "auto_trade_enabled": at.enabled if at else False,
        "scanner_running": sc.running if sc else False,
    }


@router.get("/ticker")
async def get_ticker(request: Request):
    sc = request.app.state.scanner
    if not sc:
        return []
    top = [o for o in sc.opportunities if o.get("status") == "PROFIT"][:10]
    return [{"symbol": o["symbol"], "buy_exchange": o["buy_exchange"],
             "sell_exchange": o["sell_exchange"], "network": o.get("network"),
             "net_profit_pct": o["net_profit_pct"]} for o in top]


# ══════════════════════════════════════════════════════════════════════════════
# AUTH
# ══════════════════════════════════════════════════════════════════════════════

@router.post("/auth/login")
async def login(form: OAuth2PasswordRequestForm = Depends()):
    if form.username != settings.ADMIN_USERNAME:
        raise HTTPException(401, "Invalid credentials")
    if not verify_password(form.password, settings.ADMIN_PASSWORD_HASH):
        raise HTTPException(401, "Invalid credentials")
    token = create_token({"sub": form.username, "role": "admin"})
    return {"access_token": token, "token_type": "bearer"}


# ══════════════════════════════════════════════════════════════════════════════
# CONFIG
# ══════════════════════════════════════════════════════════════════════════════

class ConfigUpdate(BaseModel):
    min_profit_pct: Optional[float] = None
    max_capital_usdt: Optional[float] = None
    slippage_pct: Optional[float] = None
    max_transfer_min: Optional[int] = None
    cooldown_seconds: Optional[int] = None
    arb_mode: Optional[str] = None
    auto_trade_enabled: Optional[bool] = None
    auto_trade_mode: Optional[str] = None
    auto_min_profit_pct: Optional[float] = None
    max_concurrent_trades: Optional[int] = None
    scanner_active: Optional[bool] = None


@router.get("/admin/config")
async def get_cfg(admin=Depends(require_admin)):
    return await get_config()


@router.put("/admin/config")
async def update_cfg(data: ConfigUpdate, admin=Depends(require_admin)):
    updates = {}
    for field, value in data.dict(exclude_none=True).items():
        updates[field] = str(value).lower() if isinstance(value, bool) else str(value)

    async with AsyncSessionLocal() as session:
        for key, value in updates.items():
            result = await session.execute(
                select(SystemConfig).where(SystemConfig.key == key)
            )
            row = result.scalar_one_or_none()
            if row:
                row.value = value
                row.updated_at = datetime.utcnow()
            else:
                session.add(SystemConfig(key=key, value=value))
        await session.commit()

    return {"status": "updated", "updated_keys": list(updates.keys())}


# ══════════════════════════════════════════════════════════════════════════════
# AUTO-TRADE CONTROL
# ══════════════════════════════════════════════════════════════════════════════

@router.post("/admin/auto-trade/enable")
async def enable_auto_trade(request: Request, admin=Depends(require_admin)):
    async with AsyncSessionLocal() as session:
        result = await session.execute(
            select(SystemConfig).where(SystemConfig.key == "auto_trade_enabled")
        )
        row = result.scalar_one_or_none()
        if row:
            row.value = "true"
        else:
            session.add(SystemConfig(key="auto_trade_enabled", value="true"))
        await session.commit()

    at = request.app.state.auto_trader
    if at:
        at.enabled = True
    logger.info("Auto-trade ENABLED by admin")
    return {"status": "auto_trade_enabled"}


@router.post("/admin/auto-trade/disable")
async def disable_auto_trade(request: Request, admin=Depends(require_admin)):
    async with AsyncSessionLocal() as session:
        result = await session.execute(
            select(SystemConfig).where(SystemConfig.key == "auto_trade_enabled")
        )
        row = result.scalar_one_or_none()
        if row:
            row.value = "false"
        else:
            session.add(SystemConfig(key="auto_trade_enabled", value="false"))
        await session.commit()

    at = request.app.state.auto_trader
    if at:
        at.enabled = False
    logger.info("Auto-trade DISABLED by admin")
    return {"status": "auto_trade_disabled"}


# ══════════════════════════════════════════════════════════════════════════════
# MANUAL EXECUTE
# ══════════════════════════════════════════════════════════════════════════════

class ExecuteRequest(BaseModel):
    opportunity_index: int
    capital: float = 120.0


@router.post("/admin/execute")
async def manual_execute(data: ExecuteRequest, request: Request, admin=Depends(require_admin)):
    config = await get_config()

    if config.get("emergency_stop", "false") == "true":
        raise HTTPException(403, "Emergency stop is active")

    sc = request.app.state.scanner
    if not sc or data.opportunity_index >= len(sc.opportunities):
        raise HTTPException(400, "Invalid opportunity index")

    opp = sc.opportunities[data.opportunity_index]

    # Validate it's still fresh
    scanned_at = opp.get("scanned_at", "")
    if scanned_at:
        try:
            age = (datetime.utcnow() - datetime.fromisoformat(scanned_at)).total_seconds()
            if age > 30:
                raise HTTPException(400, f"Opportunity is {int(age)}s old — rescan first")
        except ValueError:
            pass

    from services.executor import TradeExecutor
    executor = TradeExecutor(sc.clients)
    trade_id = await executor.execute(opp, data.capital, config, exec_mode="manual")

    return {"status": "executing", "trade_id": trade_id, "symbol": opp["symbol"]}


# ══════════════════════════════════════════════════════════════════════════════
# EMERGENCY STOP
# ══════════════════════════════════════════════════════════════════════════════

@router.post("/admin/emergency-stop")
async def emergency_stop(request: Request, admin=Depends(require_admin)):
    async with AsyncSessionLocal() as session:
        result = await session.execute(
            select(SystemConfig).where(SystemConfig.key == "emergency_stop")
        )
        row = result.scalar_one_or_none()
        if row:
            row.value = "true"
        else:
            session.add(SystemConfig(key="emergency_stop", value="true"))
        # Also disable auto-trade
        result2 = await session.execute(
            select(SystemConfig).where(SystemConfig.key == "auto_trade_enabled")
        )
        row2 = result2.scalar_one_or_none()
        if row2:
            row2.value = "false"
        await session.commit()

    sc = request.app.state.scanner
    at = request.app.state.auto_trader
    if sc:
        sc.stop()
    if at:
        at.enabled = False
        at.stop()

    logger.warning("EMERGENCY STOP activated by admin")
    return {"status": "EMERGENCY_STOP_ACTIVATED"}


@router.post("/admin/resume")
async def resume(request: Request, admin=Depends(require_admin)):
    async with AsyncSessionLocal() as session:
        result = await session.execute(
            select(SystemConfig).where(SystemConfig.key == "emergency_stop")
        )
        row = result.scalar_one_or_none()
        if row:
            row.value = "false"
        await session.commit()

    # Restart scanner
    sc = request.app.state.scanner
    if sc and not sc.running:
        import asyncio
        sc._stop.clear()
        asyncio.create_task(sc.run_forever())

    at = request.app.state.auto_trader
    if at and not at.running:
        import asyncio
        at._stop.clear()
        asyncio.create_task(at.run_forever())

    return {"status": "resumed"}


# ══════════════════════════════════════════════════════════════════════════════
# TRADE HISTORY
# ══════════════════════════════════════════════════════════════════════════════

@router.get("/admin/trades")
async def list_trades(limit: int = 50, admin=Depends(require_admin)):
    async with AsyncSessionLocal() as session:
        result = await session.execute(
            select(Trade).order_by(desc(Trade.started_at)).limit(limit)
        )
        trades = result.scalars().all()

    return [{
        "id": t.id,
        "exec_mode": t.exec_mode,
        "arb_mode": t.arb_mode,
        "symbol": t.symbol,
        "buy_exchange": t.buy_exchange,
        "sell_exchange": t.sell_exchange,
        "target_buy_price": t.target_buy_price,
        "target_sell_price": t.target_sell_price,
        "actual_buy_price": t.actual_buy_price,
        "actual_sell_price": t.actual_sell_price,
        "capital_usdt": t.capital_usdt,
        "network_used": t.network_used,
        "buy_fee_usdt": t.buy_fee_usdt,
        "sell_fee_usdt": t.sell_fee_usdt,
        "withdrawal_fee_usdt": t.withdrawal_fee_usdt,
        "total_fees_usdt": t.total_fees_usdt,
        "net_profit_usdt": t.net_profit_usdt,
        "net_profit_pct": t.net_profit_pct,
        "transfer_time_seconds": t.transfer_time_seconds,
        "tx_hash": t.tx_hash,
        "status": t.status,
        "error_message": t.error_message,
        "error_step": t.error_step,
        "started_at": t.started_at.isoformat(),
        "completed_at": t.completed_at.isoformat() if t.completed_at else None,
    } for t in trades]


@router.get("/admin/trades/{trade_id}")
async def get_trade(trade_id: int, admin=Depends(require_admin)):
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(Trade).where(Trade.id == trade_id))
        t = result.scalar_one_or_none()
    if not t:
        raise HTTPException(404, "Trade not found")
    return t


# ══════════════════════════════════════════════════════════════════════════════
# EXCHANGE KEYS
# ══════════════════════════════════════════════════════════════════════════════

class ExKeyCreate(BaseModel):
    exchange_id: str
    display_name: str
    api_key: str
    api_secret: str
    api_passphrase: Optional[str] = None
    withdrawal_enabled: bool = False
    ip_whitelist: Optional[str] = None
    note: Optional[str] = None

class ExKeyUpdate(BaseModel):
    display_name: Optional[str] = None
    api_key: Optional[str] = None
    api_secret: Optional[str] = None
    api_passphrase: Optional[str] = None
    is_enabled: Optional[bool] = None
    withdrawal_enabled: Optional[bool] = None
    ip_whitelist: Optional[str] = None
    note: Optional[str] = None


@router.get("/admin/exchanges")
async def list_exchanges(admin=Depends(require_admin)):
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(ExchangeKey))
        keys = result.scalars().all()
    return [{
        "id": k.id,
        "exchange_id": k.exchange_id,
        "display_name": k.display_name,
        "is_enabled": k.is_enabled,
        "withdrawal_enabled": k.withdrawal_enabled,
        "ip_whitelist": k.ip_whitelist,
        "note": k.note,
        "created_at": k.created_at.isoformat(),
    } for k in keys]


@router.get("/admin/exchanges/available")
async def available_exchanges(admin=Depends(require_admin)):
    return {"exchanges": EXCHANGES}


@router.post("/admin/exchanges")
async def add_exchange(data: ExKeyCreate, admin=Depends(require_admin)):
    async with AsyncSessionLocal() as session:
        existing = await session.execute(
            select(ExchangeKey).where(ExchangeKey.exchange_id == data.exchange_id)
        )
        if existing.scalar_one_or_none():
            raise HTTPException(400, f"Exchange {data.exchange_id} already configured")

        session.add(ExchangeKey(
            exchange_id=data.exchange_id,
            display_name=data.display_name,
            api_key_enc=encrypt_value(data.api_key),
            api_secret_enc=encrypt_value(data.api_secret),
            api_pass_enc=encrypt_value(data.api_passphrase) if data.api_passphrase else None,
            withdrawal_enabled=data.withdrawal_enabled,
            ip_whitelist=data.ip_whitelist,
            note=data.note,
        ))
        await session.commit()
    return {"status": "created"}


@router.put("/admin/exchanges/{exchange_id}")
async def update_exchange(exchange_id: str, data: ExKeyUpdate, admin=Depends(require_admin)):
    async with AsyncSessionLocal() as session:
        result = await session.execute(
            select(ExchangeKey).where(ExchangeKey.exchange_id == exchange_id)
        )
        key = result.scalar_one_or_none()
        if not key:
            raise HTTPException(404, "Exchange not found")

        if data.display_name is not None:    key.display_name = data.display_name
        if data.api_key is not None:         key.api_key_enc = encrypt_value(data.api_key)
        if data.api_secret is not None:      key.api_secret_enc = encrypt_value(data.api_secret)
        if data.api_passphrase is not None:  key.api_pass_enc = encrypt_value(data.api_passphrase)
        if data.is_enabled is not None:      key.is_enabled = data.is_enabled
        if data.withdrawal_enabled is not None: key.withdrawal_enabled = data.withdrawal_enabled
        if data.ip_whitelist is not None:    key.ip_whitelist = data.ip_whitelist
        if data.note is not None:            key.note = data.note
        await session.commit()
    return {"status": "updated"}


@router.delete("/admin/exchanges/{exchange_id}")
async def delete_exchange(exchange_id: str, admin=Depends(require_admin)):
    async with AsyncSessionLocal() as session:
        await session.execute(
            delete(ExchangeKey).where(ExchangeKey.exchange_id == exchange_id)
        )
        await session.commit()
    return {"status": "deleted"}


# ══════════════════════════════════════════════════════════════════════════════
# COIN CONTROL
# ══════════════════════════════════════════════════════════════════════════════

@router.get("/admin/disabled-coins")
async def get_disabled_coins(admin=Depends(require_admin)):
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DisabledCoin))
        return [{"symbol": c.symbol, "reason": c.reason,
                 "created_at": c.created_at.isoformat()} for c in result.scalars().all()]


@router.post("/admin/disabled-coins/{symbol}")
async def disable_coin(symbol: str, reason: Optional[str] = None, admin=Depends(require_admin)):
    async with AsyncSessionLocal() as session:
        existing = await session.execute(
            select(DisabledCoin).where(DisabledCoin.symbol == symbol.upper())
        )
        if not existing.scalar_one_or_none():
            session.add(DisabledCoin(symbol=symbol.upper(), reason=reason))
            await session.commit()
    return {"status": "disabled", "symbol": symbol.upper()}


@router.delete("/admin/disabled-coins/{symbol}")
async def enable_coin(symbol: str, admin=Depends(require_admin)):
    async with AsyncSessionLocal() as session:
        await session.execute(
            delete(DisabledCoin).where(DisabledCoin.symbol == symbol.upper())
        )
        await session.commit()
    return {"status": "enabled", "symbol": symbol.upper()}
